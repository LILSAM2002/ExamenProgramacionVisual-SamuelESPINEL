# 🍩 Personajes de Los Simpsons — Proyecto de Evaluación (Programación Visual, 3er semestre — TECLEMAS)

Este proyecto es una aplicación de escritorio hecha en **Java + JavaFX** que consume la API pública
[thesimpsonsapi.com](https://thesimpsonsapi.com) para mostrar personajes de la serie en tarjetas visuales.

El proyecto **ya funciona**: al ejecutarlo verás la lista de personajes cargándose desde internet.
Tu trabajo es completar **5 actividades** que hoy están marcadas con `// TODO` en el código, para que la
aplicación quede totalmente funcional.

---

## 1. Requisitos previos

- JDK 11 o superior instalado.
- Apache Maven instalado (o usa el que ya esté configurado en tu equipo/IDE).
- Conexión a internet (la app consume una API en línea).
- Un editor o IDE que soporte Maven y JavaFX (VS Code, IntelliJ, Eclipse, NetBeans).

## 2. Cómo ejecutar el proyecto

Desde la raíz del proyecto (donde está el `pom.xml`), ejecuta:

```bash
mvn clean javafx:run
```

Si todo está bien configurado, se abrirá una ventana llamada **"Personajes de Los Simpsons"** con una
barra lateral (búsqueda) y una cuadrícula de tarjetas de personajes.

## 3. Estructura del proyecto (dónde está cada cosa)

```
src/main/java/com/simposons/personajes/
├── App.java                         # Punto de entrada de la aplicación JavaFX
├── PersonajeController.java          # ⭐ AQUÍ ESTÁN LOS 5 TODOs QUE DEBES COMPLETAR
├── model/
│   ├── Personaje.java                # Representa un personaje (name, age, status, phrases, etc.)
│   └── SimpsonsResponse.java         # Representa la respuesta paginada de la API
└── service/
    └── SimpsonsService.java          # Hace la petición HTTP y convierte el JSON a objetos Java

src/main/resources/com/simposons/personajes/
├── personaje.fxml                    # Diseño visual de la pantalla (ya está listo, no debes tocarlo)
└── styles.css                        # Estilos visuales (ya está listo, no debes tocarlo)
```

**No necesitas modificar `App.java`, `Personaje.java`, `SimpsonsResponse.java`, `SimpsonsService.java`,
`personaje.fxml` ni `styles.css`.** Todo tu trabajo va **dentro de `PersonajeController.java`**, en los
5 métodos marcados con comentarios `// TODO ACTIVIDAD n:`.

> 💡 Tip: en tu editor, busca la palabra `TODO` (Ctrl+F o el buscador de "TODOs" de tu IDE) dentro de
> `PersonajeController.java` para saltar directo a cada actividad.

---

## 4. Las 5 actividades que debes completar

Cada actividad es independiente. Te recomendamos hacerlas en este orden porque va de menor a mayor
complejidad.

### ✅ Actividad 1 — Diálogo "Ver detalles" del personaje

**Dónde:** método `showCharacterDetails(Personaje character)`.

**Qué debe pasar:** al hacer clic en el botón **"Ver detalles"** de cualquier tarjeta, debe abrirse una
ventana/diálogo modal (bloquea la ventana principal hasta que se cierre) mostrando **toda** la
información del personaje:

- Retrato (imagen) — puedes reutilizar el método `createCharacterImage(character)` que ya existe.
- Nombre.
- Ocupación.
- Edad.
- Estado (`status`: Alive/Deceased).
- Género (`gender`).
- Fecha de nacimiento (`birthdate`).
- **Todas** las frases del personaje (`character.getPhrases()`), no solo la primera como hace la tarjeta.
- Un botón para cerrar el diálogo.

**Pistas técnicas:** puedes usar `javafx.scene.control.Alert` (con `AlertType.NONE` y tu propio contenido),
o crear un `javafx.stage.Stage` nuevo con `initModality(Modality.APPLICATION_MODAL)`. Muéstralo con
`showAndWait()`.

**Cómo saber que quedó bien:** al hacer clic en "Ver detalles" de cualquier personaje, ves un diálogo con
toda su información y puedes cerrarlo con un botón.

---

### ✅ Actividad 2 — Botón "➕ Cargar Más" (paginación)

**Dónde:** método `handleLoadMore()` (ya está conectado al botón en el FXML, solo falta el cuerpo).

**Qué debe pasar:** cada clic en el botón **"➕ Cargar Más"** debe traer la **siguiente página** de
personajes desde la API y agregarlos al final de la cuadrícula, sin borrar los que ya estaban.

**Pistas técnicas:** existe una variable estática `currentPage` que ya se usa dentro de
`loadMoreCharacters()` para pedir la página correspondiente. Solo te falta incrementarla
(`currentPage++`) y llamar a `loadMoreCharacters()`.

**Cómo saber que quedó bien:** al abrir la app ves la página 1. Cada clic en "Cargar Más" agrega más
tarjetas debajo de las anteriores (página 2, 3, 4...).

---

### ✅ Actividad 3 — Búsqueda por nombre

**Dónde:** método `handleSearch()` (ya conectado al botón "🔍 Buscar").

**Qué debe pasar:** el usuario escribe un nombre (o parte de un nombre) en el campo de texto de la barra
lateral (`searchField`) y al hacer clic en "🔍 Buscar", la cuadrícula debe mostrar **solo** los personajes
ya cargados en memoria (`currentCharactersLists`) cuyo nombre contenga ese texto (sin importar
mayúsculas/minúsculas). Si el campo está vacío, se deben volver a mostrar todos los personajes cargados.

**Pistas técnicas:**
- Lee el texto con `searchField.getText().trim()`.
- Filtra la lista `currentCharactersLists` comparando con `character.getName().toLowerCase().contains(...)`.
- Limpia `charactersContainer.getChildren()` antes de volver a pintar las tarjetas filtradas.
- Reutiliza `createCharacterCard(character)` para no reescribir la lógica visual de la tarjeta.

**Cómo saber que quedó bien:** si escribes "Homer" y buscas, solo ves tarjetas de personajes que
contengan "Homer" en el nombre. Si borras el texto y buscas de nuevo, vuelves a ver todos.

---

### ✅ Actividad 4 — Botón "🎲 Aleatorio"

**Dónde:** método `handleRandom()` (ya conectado al botón).

**Qué debe pasar:** al hacer clic en "🎲 Aleatorio", se elige **al azar** un personaje de los ya cargados
(`currentCharactersLists`) y se le abre el mismo diálogo de detalles de la **Actividad 1**.

**Pistas técnicas:**
- Usa `new java.util.Random().nextInt(currentCharactersLists.size())` para obtener un índice válido.
- Si la lista está vacía (todavía no ha cargado nada), no hagas nada o muestra un mensaje.
- Llama a `showCharacterDetails(personajeElegido)`.

**Cómo saber que quedó bien:** cada clic en "🎲 Aleatorio" abre el diálogo de detalles de un personaje
distinto (o al menos aleatorio) de los que ya están cargados.

---

### ✅ Actividad 5 — Mensaje visual de error

**Dónde:** dentro de `loadTask.setOnFailed(...)`, en el método `loadMoreCharacters()`.

**Qué debe pasar:** hoy, si falla la conexión a la API, solo se imprime un mensaje en la consola
(`System.out.println("Fallo el consumo de webservices")`). Debes mostrar además un mensaje **visible en
la interfaz** para el usuario, usando el `Label` que ya existe en el FXML: `statusMessageLabel`.

**Pistas técnicas:**
- Ponle texto: `statusMessageLabel.setText("No se pudieron cargar los personajes. Intenta de nuevo.")`.
- Hazlo visible: `statusMessageLabel.setVisible(true)` y `statusMessageLabel.setManaged(true)`.
- `setOnFailed` ya se ejecuta en el hilo de JavaFX, así que puedes tocar el Label directamente, sin
  `Platform.runLater`.

**Cómo saber que quedó bien:** si simulas un fallo (por ejemplo, desconectando el internet un momento y
haciendo clic en "Cargar Más"), aparece un mensaje visible en la app, no solo en la consola.

---

## 5. Entrega — ¡MUY IMPORTANTE!

Debes subir tu código desarrollado a **tu propio repositorio de GitHub**. La entrega **no es válida** si
el código no está en GitHub.

Pasos:

1. Crea un repositorio **propio** (público o privado, según indique tu docente) en tu cuenta de GitHub.
   Usa como referencia de nombre/estructura el repositorio de la asignatura:
   👉 https://github.com/wgaibor/ExamenProgramacionVisualA26
2. Sube TODO el proyecto (incluyendo `pom.xml`, `src/`, este `README.md` y los archivos de evaluación)
   a tu repositorio, con commits que reflejen tu progreso (idealmente un commit por actividad
   completada).
3. Verifica que el repositorio sea accesible y que el proyecto compile con `mvn clean javafx:run` desde
   una copia limpia (clona tu propio repo en otra carpeta y pruébalo).
4. Entrega a tu docente el **enlace de tu repositorio de GitHub**.

**No se aceptan entregas en .zip, correo, USB, ni ninguna otra vía: la entrega oficial es el enlace a tu
repositorio de GitHub.**

---

## 6. Evaluación

Esta evaluación tiene dos partes con el mismo peso:

- **50% Teoría:** ver `EVALUACION_ESTUDIANTE.md` (preguntas de selección múltiple, verdadero/falso y
  emparejar conceptos, sobre Maven, consumo de APIs, Jackson y JavaFX).
- **50% Práctica:** las 5 actividades descritas arriba, subidas a tu repositorio de GitHub.

¡Éxitos! 🍩
